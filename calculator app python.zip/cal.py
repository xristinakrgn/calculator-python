
import datetime
from datetime import date
import calendar
import csv


# Βρίσκω τωρινό έτος, μήνα, μέρα και ώρα.
current_year = date.today().year
current_month = date.today().month
current_day = date.today().day
now = datetime.datetime.now()
current_hour = now.hour


# Δημιουργεί csv file αν δεν υπάρχει και προστίθονται τίτλοι, αν υπάρχει φορτώνει τα δεδομένα.
header = ['Date', 'Hour', 'Duration', 'Title']
try:
    with open('events.csv', 'r', encoding ='utf8', newline ='') as f:
        if f.read(1) == '':
            raise FileNotFoundError
except FileNotFoundError:
    with open('events.csv', 'w', encoding ='utf8', newline ='') as f:
        thewriter = csv.writer(f)
        header = ['Date', 'Hour', 'Duration', 'Title']
        thewriter.writerow(header)
    f.close()


# 2ο Μπόνους: Εμφανίζει ειδοποίηση για τα γεγονόντα που είναι προγραμματισμένα την σημερινή μέρα.

csv_file = csv.reader(open('events.csv', 'r', encoding = 'utf8', newline = ''))
# Μετατρέπονται οι ακέραιοι σε string.
converted_year = "% s" % current_year
converted_month = "% s" % current_month
converted_day = "% s" % current_day

for row in csv_file:
    if row[0]!='Date':
        date_object = datetime.datetime.strptime(row[0], "%Y-%m-%d")
        year_y3 = date_object.year
        month_m3 = date_object.month
        day_d3 = date_object.day
        # Ελέγχει αν το έτος, ο μήνας και η ημέρα υπάρχουν στην γραμμή.
        if int(converted_year) == year_y3 and int(converted_month) == month_m3 and int(converted_day) == day_d3:
            # Mετατροπή της λίστας της ώρας σε string για να μπορεί να γίνει ακέραιος και να εκτελεσθεί η αφαίρεση.
            x = row[1]
            y = ''.join(x)
            # Υπολογισμός υπολοιπόμενου χρόνου.
            hours_left = int(y[0:2]) - current_hour
            if hours_left != 0:
                if hours_left > 1:
                    print('Ειδοποίηση: σε', hours_left, 'ώρες από τώρα έχει προγραμματιστεί το γεγονός «', row[3], '»')
                else:
                    print('Ειδοποίηση: σε', hours_left, 'ώρα από τώρα έχει προγραμματιστεί το γεγονός «', row[3], '»')


# Χρήση dictionary για ονόματα μηνών στο Αρχικό Ημερολόγιο.
months = {1: 'ΙΑΝ', 2: 'ΦΕΒ', 3: 'ΜΑΡ', 4: 'ΑΠΡ', 5: 'ΜΑΙ', 6: 'ΙΟΥΝ', 7: 'ΙΟΥΛ', 8: 'ΑΥΓ',
          9: 'ΣΕΠ', 10: 'ΟΚΤ', 11: 'ΝΟΕ', 12: 'ΔΕΚ'}
# Ορίζει ότι το Ημερολόγιο θα έχει για 1η μέρα την Δευτέρα.
calendar.setfirstweekday(calendar.MONDAY)


# Επιλογή "-" μας δίνει τον προηγούμενο μήνα.
def previous_month():
    # Κάνω τις μεταβλητές global αντί να τις αφήσω ως local για να μπορώ να τις αλλάξω
    global current_month
    global current_year
    last_year = current_year - 1
    if current_month != 1:
        current_month = current_month - 1
    else:
        current_year = last_year
        current_month = 12
    calen()


# Επιλογή ENTER μας δίνει τον επόμενο μήνα.
def next_month():
    # Κάνω τις μεταβλητές global αντί να τις αφήσω ως local για να μπορώ να τις αλλάξω.
    global current_month
    global current_year
    next_year = current_year + 1
    if current_month < 12:
        current_month = current_month + 1
    else:
        current_year = next_year
        current_month = 1
    calen()


# Επιλογή 1
def add_note():
    global mytime, mydur
    # Έλεγχος εγκυρότητας ημερομηνίας.
    while True:
        try:
            mydate = input('Ημερομηνία γεγονόντος (ΥΥΥΥ-ΜΜ-DD):')
            date_format = ('%Y-%m-%d')
            dateObject = datetime.datetime.strptime(mydate, date_format)
            if not (mydate[0] + mydate[1] + mydate[2] + mydate[3] > '2022'):
                raise ValueError
        except ValueError:
            print("Παρακαλώ εισαγάγετε έγκυρη ημερομηνία σε μορφή ΥΥΥΥ-ΜΜ-DD και με έτος μεγαλύτερο του 2022.")
        else:
            break

    # Έλεγχος εγκυρότητας ώρας.
    while True:
        try:
            mytime = input('Ώρα γεγονόντος (HH:MM):')
            pattern_time = ('%H:%M')
            timeObject = datetime.datetime.strptime(mytime, pattern_time)
        except ValueError:
            print('Παρακαλώ εισαγάγετε έγκυρη ώρα σε μορφή HH:MM.')
            continue
        else:
            break

    # Έλεγχος εγκυρότητας διάρκειας.
    while True:
        try:
            mydur = int(input('Διάρκεια γεγονότος:'))
            if mydur < 0:
                raise ValueError
        except ValueError:
            print('Παρακαλώ εισαγάγετε έγκυρο αριθμό διάρκειας (θετικός ακέραιος).')
            continue
        else:
            break

    # Έλεγχος εγκυρότητας τίτλου.
    while True:
        try:
            mytitle = input('Τίτλος γεγονότος:')
            if "," in mytitle:
                raise ValueError

            # Αποθηκεύει γεγονός στο csv file.
            with open('events.csv', 'a', encoding = 'utf8', newline = '') as f:
                thewriter = csv.DictWriter(f, fieldnames = header)
                thewriter.writerow({'Date': mydate,'Hour': mytime,'Duration': mydur,'Title': mytitle})
            f.close()

            print('\nΤο γεγονός αποθηκεύτηκε επιτυχώς.\n')
        except ValueError:
            print('Ο Τίτλος δεν πρέπει να περιέχει τον χαρακτήρα κόμμα.')
            continue
        else:
            break
    return plus_menu()


# Επιλογή 2
def delete_note():
    print('\n=== Αναζήτηση γεγονότων ====\n')
    # Έλεγχος εγκυρότητας έτους.
    while True:
        try:
            delyear = input('Εισάγετε έτος:')
            date_format = '%Y'
            dateObject = datetime.datetime.strptime(delyear, date_format)
            if not (delyear > '2022'):
                raise ValueError
        except ValueError:
            print("Παρακαλώ εισαγάγετε έγκυρο έτος.")
        else:
            break
    # Έλεγχος εγκυρότητας μήνα.
    while True:
        try:
            delmonth = input('Εισάγετε μήνα:')
            date_format = '%m'
            dateObject = datetime.datetime.strptime(delmonth, date_format)
        except ValueError:
            print("Παρακαλώ εισαγάγετε έγκυρο μήνα.")
        else:
            break
    # Εμφάνιση γεγονόντων συγκεκριμένου έτους και μήνα.
    print()
    while True:
        try:
            csv_file = csv.reader(open('events.csv', 'r', encoding ='utf8', newline =''))
            i = 1  # Απλός μετρητής.
            ly = 0
            for line in csv_file:
                for row in csv_file:
                    date_object = datetime.datetime.strptime(row[0], "%Y-%m-%d")
                    year_y2 = date_object.year
                    month_m2 = date_object.month
                    if int(delyear) == year_y2 and int(delmonth) == month_m2:
                        print(' ', ly, '. [', row[3], '] -> Date: ', row[0], ', Time: ', row[1], ', Duration: ', row[2], sep='')
                        ly += 1
                        i += 1  # Αν αλλάξει η τιμή του μετρητή τότε υπάρχει τουλάχιστον ένα γεγονός.
            f.close()
            if i == 1:  # Αν η τιμή του μετρητή παραμείνει 1 τότε δεν υπάρχουν γεγονόντα.
                print('\nΔεν υπάρχουν γεγονότα.')
            else:
                print()
                ly = ly - 1
                # Επιλογή γεγονόντος που θα διαγραφεί.
                while True:
                    try:
                        n = int(input('Επιλέξτε γεγονός προς διαγραφή:'))
                        if (n < 0 or n > ly):
                            raise ValueError
                        else:
                            data = []
                            with open('events.csv','r', encoding = 'utf8', newline = '') as file:
                                reader = csv.DictReader(file)
                                i = 0
                                for row in reader:
                                    if i != n:
                                        data.append(row)
                                    i += 1
                            file.close() 
                            
                            with open("events.csv", "w", encoding = 'utf8', newline = '') as file2:
                                print('\nΤο γεγονός διαγράφηκε επιτυχώς')
                                # Περιγράφουμε τις στήλες του αρχείου CSV.
                                fieldnames = ['Date', 'Hour', 'Duration', 'Title']
                                # Φτιάχνουμε έναν γραμματογράφο (writer).
                                writer = csv.DictWriter(file2, fieldnames = fieldnames)

                                # Γράφουμε την επικεφαλίδα των στηλών.
                                writer.writeheader()
                                # Γράφουμε τα δεδομένα του λεξικού (dictionary).
                                for row in data:
                                    writer.writerow(row)     
                            f.close()
                    except ValueError:
                        print('Παρακαλώ εισαγάγετε έγκυρο αριθμό γεγονόντος ( 0 -', ly, ').')
                        continue
                    else:
                        break
        finally:
            # Επιστροφή στο Κυρίως Μενού.
            input('\nΠατήστε οποιοδήποτε χαρακτήρα για επιστροφή στο κυρίως μενού:\n')
            return menu()


# Επιλογή 3
def change_note():
    print('\n=== Αναζήτηση γεγονότων ====\n')
    # Έλεγχος εγκυρότητας έτους.
    while True:
        try:
            delyear = input('Εισάγετε έτος:')
            date_format = '%Y'
            dateObject = datetime.datetime.strptime(delyear, date_format)
            if not (delyear > '2022'):
                raise ValueError
        except ValueError:
            print("Παρακαλώ εισαγάγετε έγκυρο έτος.")
        else:
            break
    # Έλεγχος εγκυρότητας μήνα.
    while True:
        try:
            delmonth = input('Εισάγετε μήνα:')
            date_format = '%m'
            dateObject = datetime.datetime.strptime(delmonth, date_format)
        except ValueError:
            print("Παρακαλώ εισαγάγετε έγκυρο μήνα.")
        else:
            break
    # Εμφάνιση γεγονόντων συγκεκριμένου έτους και μήνα.
    print()
    while True:
        try:
            csv_file = csv.reader(open('events.csv', 'r', encoding ='utf8', newline =''))
            i = 1  # Απλός μετρητής.
            ly = 0
            for line in csv_file:
                for row in csv_file:
                    date_object = datetime.datetime.strptime(row[0], "%Y-%m-%d")
                    year_y2 = date_object.year
                    month_m2 = date_object.month
                    if int(delyear) == year_y2 and int(delmonth) == month_m2:
                        print(' ', ly, '. [', row[3], '] -> Date: ', row[0], ', Time: ', row[1], ', Duration: ', row[2], sep='')
                        ly += 1
                        i += 1  # Αν αλλάξει η τιμή του μετρητή τότε υπάρχει τουλάχιστον ένα γεγονός.
            f.close()
            if i == 1:  # Αν η τιμή του μετρητή παραμείνει 1 τότε δεν υπάρχουν γεγονόντα.
                print('\nΔεν υπάρχουν γεγονότα.')
            else:
                print()
                ly = ly - 1
                # Επιλογή γεγονόντος που θα ενημερωθεί.
                while True:
                    try:
                        n = int(input('Επιλέξτε γεγονός προς ενημέρωση: '))
                        if (n < 0 or n > ly):
                            raise ValueError
                    except ValueError:
                        print('Παρακαλώ εισαγάγετε έγκυρο αριθμό γεγονόντος ( 0 -',ly,').')
                        continue
                    else:
                        break


                
            with open('events.csv','r+', encoding = 'utf8', newline = '') as firstfile, open('events.csv','a', encoding = 'utf8', newline = '') as secondfile:
                number_of_lines = len(firstfile.readlines())
                for line in firstfile:

                    if delyear in line and delmonth in line:
                        secondfile.writelines(line)
            firstfile.close()
            secondfile.close()


            line_number = n
            file = open('events.csv', 'r', encoding = 'utf8', newline = '')
            lines = file.readlines()
            file.close()
            line = lines[ (len(lines)- ly) + line_number - 1].rstrip('\n')


            print('Ημερομηνία γεγονότος (',line[0:10], '):')
            d = input('')
            date_format = ('%Y-%m-%d')
            dateObject = datetime.datetime.strptime(d, date_format)
            if d == "":
                newdate = str(line[0:10])
            else:
                while True:
                    if dateObject != datetime.datetime.strptime(d, date_format) and not (d[0] + d[1] + d[2] + d[3] > '2022'):
                        print("Παρακαλώ εισαγάγετε έγκυρη ημερομηνία σε μορφή ΥΥΥΥ-ΜΜ-DD και με έτος μεγαλύτερο του 2022.")
                        print('Ημερομηνία γεγονότος (',line[0:10], '):')
                        d = input('')
                    else:
                        break
                newdate = d

            
            print('Ώρα γεγονότος (', line[11:16], '):')
            t = input('')
            pattern_time = ('%H:%M')
            timeObject = datetime.datetime.strptime(t, pattern_time)
            if t == "":
                newtime = str(line[11:16])
            else:
                while True:
                    if timeObject != datetime.datetime.strptime(t, pattern_time):
                        print('Παρακαλώ εισαγάγετε έγκυρη ώρα σε μορφή HH:MM.')
                        print('Ώρα γεγονότος (', line[11:16], '):')
                        t = input('')
                    else:
                        break
                newtime = t
            
            print('Διάρκεια γεγονότος (', line[17:19].strip(), '):')
            du = input('')
            if du == "":
                newdu = str( line[17:19] )
            else:
                while True:
                    if du <= 0:
                        print('Παρακαλώ εισαγάγετε έγκυρο αριθμό διάρκειας (θετικός ακέραιος).')
                        print('Διάρκεια γεγονότος (', line[17:19].strip(), '):')
                        du = input('')
                    else:
                        break
                newdu = du
            
            print('Τίτλος γεγονότος(' , line[20:].strip() , '):')
            ti = input('')
            if ti == "":
                newti = str(line[20:].strip())
            else:
                while True:
                    if "," in ti:
                        print('Ο Τίτλος δεν πρέπει να περιέχει τον χαρακτήρα κόμμα.')
                        print('Τίτλος γεγονότος(' , line[20:].strip() , '):')
                        ti = input('')
                    else:
                        break                    
                newti = ti

            print('\nΤο γεγονός ενημερώθηκε: <[',newti, '] -> Date: ',newdate, ', Time: ',
                newtime, ', Duration: ', newdu, '>')

            with open('events.csv', 'a+',encoding = 'utf8', newline='',) as write_obj:
        # Create a writer object from csv module
                fieldnames = ['Date', 'Hour', 'Duration', 'Title']
                newevent = {'Date': newdate,'Hour': newtime,'Duration': newdu,'Title': newti }
                csv_writer = csv.DictWriter(write_obj,fieldnames=fieldnames)
        # Add contents of list as last row in the csv file
                csv_writer.writerow(newevent)
            write_obj.close()

        # Επιστροφή στο Κυρίως Μενού.
        finally:
            input('\nΠατήστε οποιοδήποτε χαρακτήρα για επιστροφή στο κυρίως μενού:\n')
            return menu()


# Επιλογή "*" μας εμφανίζει γεγονόντα επιλεγμένου μήνα.
def star():
    print('\n=== Αναζήτηση γεγονότων ====\n')
    # Έλεγχος εγκυρότητας έτους.
    while True:
        try:
            delyear = input('Εισάγετε έτος:')
            date_format = '%Y'
            dateObject = datetime.datetime.strptime(delyear, date_format)
            if not (delyear > '2022'):
                raise ValueError
        except ValueError:
            print("Παρακαλώ εισαγάγετε έγκυρο έτος.")
        else:
            break
    # Έλεγχος εγκυρότητας μήνα.
    while True:
        try:
            delmonth = input('Εισάγετε μήνα:')
            date_format = '%m'
            dateObject = datetime.datetime.strptime(delmonth, date_format)
        except ValueError:
            print("Παρακαλώ εισαγάγετε έγκυρο μήνα.")
        else:
            break
    # Εμφάνιση γεγονόντων συγκεκριμένου έτους και μήνα.
    print()
    while True:
        try:
            csv_file = csv.reader(open('events.csv', 'r', encoding ='utf8', newline =''))
            i = 1  # Απλός μετρητής.
            ly = 0
            for line in csv_file:
                for row in csv_file:
                    date_object = datetime.datetime.strptime(row[0], "%Y-%m-%d")
                    year_y2 = date_object.year
                    month_m2 = date_object.month
                    if int(delyear) == year_y2 and int(delmonth) == month_m2:
                        print(' ', ly, '. [', row[3], '] -> Date: ', row[0], ', Time: ', row[1], ', Duration: ', row[2], sep='')
                        ly += 1
                        i += 1  # Αν αλλάξει η τιμή του μετρητή τότε υπάρχει τουλάχιστον ένα γεγονός.
            f.close()
            if i == 1:  # Αν η τιμή του μετρητή παραμείνει 1 τότε δεν υπάρχουν γεγονόντα.
                print('\nΔεν υπάρχουν γεγονότα.')

        finally:
            # Επιστροφή στο Κυρίως Μενού.
            input('\nΠατήστε οποιοδήποτε χαρακτήρα για επιστροφή στο κυρίως μενού:\n')
            return menu()


# Δεύτερο μενού (Εμφανίζεται με εισαγωγή "+").
def plus_menu():
    print('----------------------------------------------------')
    print('Διαχείριση γεγονότων ημερολογίου, επιλέξτε ενέργεια:')
    print('    1 Καταγραφή νέου γεγονότος\n    2 Διαγραφή γεγονότος\n    3 Ενημέρωση γεγονότος\n    0 Επιστροφή στο κυρίως μενού')
    reply = input('    ->')
    if reply == "0":
        menu()
    elif reply == "1":
        add_note()
    elif reply == "2":
        delete_note()
    elif reply == "3":
        change_note()


# Αρχικό Ημερολόγιο.
def calen():
    global current_month
    cal = calendar.monthcalendar(current_year, current_month)

    # Μήνας, Έτος, Ονόματα ημερών.
    print('_________________________________________________')
    print(months[current_month], current_year)
    print('_________________________________________________')
    print('  ΔΕΥ |  ΤΡΙ |  ΤΕΤ |  ΠΕΜ |  ΠΑΡ |  ΣΑΒ |  ΚΥΡ')
    # Ημέρες
    border = ''
    # Βρίσκω τον αριθμό των ημερών του προηγούμενου μήνα.
    if current_month != 1:
        _, num_days = calendar.monthrange(current_year, current_month - 1)
    else:
        _, num_days = calendar.monthrange(current_year - 1, 12)
    # Βρίσκω που αρχίζει ο τωρινός μήνας και τον αριθμό των ημερών του τωρινού μήνα.
    first_day, num2 = calendar.monthrange(current_year, current_month)
    # Με αυτή την αφαίρεση βρίσκω την πρώτη ημέρα που πρέπει να εμφανίσω.
    num_days -= first_day - 1
    i = 1
    x = False
    a = False
    for week in cal:
        line = border
        for day in week:
            
            with open('events.csv','r', encoding ='utf8', newline ='') as ff:
                
                reader = csv.reader(ff)
                next(reader)
                
                for row in reader:
                    
                    date_object = datetime.datetime.strptime(row[0], "%Y-%m-%d")
                    year_y = date_object.year
                    month_m = date_object.month
                    day_d = date_object.day
                    
                    if current_year == year_y and current_month == month_m and day == day_d:
                        a = True
                        break
                    else:
                        a = False
            ff.close()
            
            if day == 0:
                # Μέρες που δεν ανήκουν στον μήνα.
                if x == False:
                    line += '   %d |' % num_days
                    num_days += 1
                else:
                    line += '    %d |' % i
                    i += 1
            # Μέρες με αριθμό ενός ψηφίου (π.χ. 3).
            elif len(str(day)) == 1:
                if a == True:
                    line += '[ *%d] |' % day
                    x = True
                else:
                    line += '[  %d] |' % day
                    x = True
            # Μέρες με αριθμό δύο ψηφίων (π.χ. 12).
            else:
                if a == True:
                    line += '[*%d] |' % day
                    x = True
                else:
                    line += '[ %d] |' % day
                    x = True
        # Αφαίρεση καθέτου στην δεξιά πλευρά του ημερολογίου.
        line = line[0:len(line) - 1]
        line += border
        print(line)
    print('_________________________________________________\n')


# Kυρίως μενού.
def menu():
    calen()
    while True:
        print('Πατήστε ENTER για προβολή του επόμενου μήνα, "q" για έξοδο ή κάποια από τις παρακάτω επιλογές:')
        print('    "-" για πλοήγηση στον προηγούμενο μήνα\n    "+" για διαχείριση των γεγονότων του ημερολογίου\n    "*" για εμφάνιση των γεγονότων ενός επιλεγμένου μήνα')
        reply = input('    ->')
        if reply == "q" or reply == "Q":
            break
        elif reply == "-":
            previous_month()
        elif reply == "+":
            plus_menu()
        elif reply == "*":
            star()
        if reply == "":
            next_month()

menu()